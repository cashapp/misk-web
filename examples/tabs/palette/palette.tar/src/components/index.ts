import SampleTableComponent from "./SampleTableComponent"
export { SampleTableComponent }
