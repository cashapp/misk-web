const { createPrettierConfig } = require("@misk/dev")
module.exports = createPrettierConfig()
